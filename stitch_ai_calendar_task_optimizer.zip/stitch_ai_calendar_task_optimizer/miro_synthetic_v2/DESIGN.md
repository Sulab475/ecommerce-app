# Design System Documentation: Synthetic Intelligence Editorial

## 1. Overview & Creative North Star
### The North Star: "The Ethereal Engine"
This design system is not a static interface; it is a high-performance environment designed to feel like a living, breathing extension of the user's cognitive process. We are moving away from "SaaS-standard" dashboards toward a **High-End Editorial** experience. 

The aesthetic is "The Ethereal Engine"—a sophisticated blend of raw computational power and cinematic clarity. By leveraging **Space Grotesk’s** technical geometric quirks against a backdrop of deep obsidian and electric cyan (#1BBADE), we create a space that feels both authoritative and infinitely scalable. We break the "template" look through intentional asymmetry, massive typographic scale shifts, and the complete elimination of structural lines in favor of tonal depth.

---

## 2. Colors: Tonal Architecture
The palette is rooted in a deep-space dark mode, utilizing the primary `#1BBADE` (represented by the `primary` and `primary_container` tokens) as a functional light source rather than just a decorative accent.

### The "No-Line" Rule
**Strict Mandate:** Traditional 1px solid borders are prohibited for sectioning. 
Structure must be defined through **Background Color Shifts**. For example, a sidebar using `surface_container_low` should sit against a main viewport of `surface`. The eye should perceive the change in depth through the shift in hex value, not a stroke.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of tinted obsidian.
*   **Base:** `surface_dim` (#001018)
*   **Level 1 (Sections):** `surface_container_low` (#00161f)
*   **Level 2 (Cards/Modules):** `surface_container` (#001c28)
*   **Level 3 (Popovers/Active):** `surface_container_highest` (#002939)

### The "Glass & Gradient" Rule
To inject "soul" into the AI environment, use **Glassmorphism** for floating toolbars and modal overlays. Use `surface_variant` at 60% opacity with a `24px` backdrop blur. 
*   **Signature Texture:** Primary CTAs should not be flat. Apply a subtle linear gradient from `primary` (#50d9fe) to `primary_container` (#06b5d9) at a 135-degree angle to create a sense of internal illumination.

---

## 3. Typography: Technical Elegance
We use **Space Grotesk** exclusively. Its tabular-leaning feel communicates precision, while its open apertures maintain readability at small sizes.

*   **Display (lg/md):** Use for high-impact data points or welcome states. Use `-0.04em` letter spacing to create a "tight," editorial feel.
*   **Headlines:** These are your anchors. Pair `headline-lg` with `primary` color tokens to draw the eye to the start of a flow.
*   **Body:** `body-md` is our workhorse. Ensure a line-height of 1.5 to provide breathing room against the high-contrast background.
*   **Labels:** Use `label-sm` in `on_surface_variant` for metadata. This keeps the "technical" feel without cluttering the visual hierarchy.

---

## 4. Elevation & Depth: Tonal Layering
We reject the drop-shadow defaults of the past decade. Depth is achieved through light, not shadow.

*   **The Layering Principle:** Instead of a shadow, place a `surface_container_highest` element over a `surface_dim` background. The contrast in luminescence creates a natural lift.
*   **Ambient Shadows:** If a floating element (like a context menu) requires a shadow, use a large `48px` blur with 6% opacity. The shadow color must be `on_background` (#c7ebff) to simulate light refracting through the UI, rather than a muddy black shadow.
*   **The "Ghost Border" Fallback:** If a container requires a boundary for accessibility, use the `outline_variant` token at **15% opacity**. It should be felt, not seen.

---

## 5. Components: Modular Primitives

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary_container`). `0.25rem` (4px) border-radius. Text is `on_primary_container`.
*   **Secondary:** No fill. `Ghost Border` (outline-variant @ 20%). Text is `primary`.
*   **Tertiary:** Plain text in `primary` with no container. Use for low-priority actions.

### Input Fields
*   **State:** Default state is `surface_container`. On focus, the background shifts to `surface_container_high` and a 1px `primary` "Ghost Border" appears. 
*   **Typography:** User input should always be `body-md` in `on_surface`.

### Cards & Lists
*   **No Dividers:** Forbid the use of horizontal rules. Use `1.5rem` of vertical whitespace or a subtle background shift to `surface_container_low` to separate list items.
*   **Asymmetry:** In grid layouts, vary the height of cards slightly to break the "table" feel, creating a more dynamic, editorial rhythm.

### AI Processing Chips
*   **Visual:** Use `tertiary_container` with a subtle pulse animation. These should feel "active" and distinct from standard selection chips.

---

## 6. Do’s and Don’ts

### Do:
*   **Use Asymmetric Grids:** Align text to the left but allow imagery or data visualizations to bleed off-grid to the right.
*   **Embrace Negative Space:** If a screen feels "empty," leave it. High-performance tools require "resting zones" for the eyes.
*   **Color as Data:** Use `primary` (#50d9fe) strictly for interaction and `error` (#ff716c) for critical alerts. Do not use them for decoration.

### Don’t:
*   **Don’t use 100% White:** Never use #FFFFFF. Use `on_surface` (#c7ebff) for text to prevent eye strain in dark mode.
*   **Don’t use Heavy Roundedness:** Keep to the `DEFAULT` (0.25rem) or `md` (0.375rem) scales. Rounding everything to `full` (pill-shaped) makes the system feel like a toy; we are building a tool.
*   **Don’t use Dividers:** If you find yourself reaching for a `<hr>` tag, use a `1px` shift in background color instead.