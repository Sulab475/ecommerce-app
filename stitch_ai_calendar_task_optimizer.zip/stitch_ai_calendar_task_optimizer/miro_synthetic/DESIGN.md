# Design System Strategy: The Cognitive Architect

This design system serves as the foundational visual language for a high-performance, AI-driven productivity environment. Moving beyond the sterile conventions of typical SaaS platforms, this system embraces an "Editorial Tech" aesthetic—combining the precision of data-driven interfaces with the sophisticated depth of high-end digital craftsmanship.

## 1. Overview & Creative North Star: "The Cognitive Architect"
The Creative North Star for this system is **"The Cognitive Architect."** 

This concept views the interface not as a flat tool, but as a multi-dimensional workspace where AI-generated insights emerge from the shadows. To break the "template" look, the system utilizes a high-contrast typographic scale (Space Grotesk vs. Inter) and intentional asymmetry. Elements are not always contained in rigid boxes; they overlap and bleed, suggesting a fluid, intelligent flow of information rather than a static spreadsheet.

## 2. Color & Tonal Depth
The palette is rooted in a deep, nocturnal foundation, punctuated by "light-source" colors that represent AI intelligence and user action.

*   **Primary Palette:** `primary` (#4cd6fb) and `primary_container` (#00b4d8) represent the "active mind" of the AI. Use these for primary actions and focus states.
*   **Secondary Palette:** `secondary` (#95d4b3) is reserved for "Synthesized Data"—outputs that the AI has successfully processed or refined.
*   **Tertiary Highlights:** `tertiary` (#ffba27) acts as the "Notification of Insight." Use sparingly for high-attention alerts or breakthrough productivity moments.

### The "No-Line" Rule
Traditional UI relies on 1px borders to separate content. **This design system prohibits 1px solid borders for sectioning.** Boundaries must be defined through:
1.  **Background Shifts:** Placing a `surface_container_low` card against a `surface` background.
2.  **Tonal Transitions:** Using soft gradients to suggest where one zone ends and another begins.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the `surface_container` tiers to create depth:
*   **Base:** `surface_dim` (#061423) for the primary application canvas.
*   **Level 1:** `surface_container_low` for large sidebar or utility areas.
*   **Level 2:** `surface_container_high` for primary content cards.
*   **Level 3:** `surface_bright` for floating modals or active pop-overs.

### Signature Textures
To provide "soul," main CTAs and Hero sections must utilize a linear gradient from `primary` to `primary_container` at a 135-degree angle. This provides a professional polish that flat fills cannot replicate.

## 3. Typography: The Editorial Scale
The system pairs the brutalist, tech-forward **Space Grotesk** for high-level information with the utilitarian precision of **Inter** for deep work.

*   **The Display Tier (Space Grotesk):** Use `display-lg` and `display-md` for data visualizations and AI-generated headlines. These should feel authoritative and large, often using negative letter-spacing (-0.02em) to feel "tighter" and more premium.
*   **The Headline Tier (Space Grotesk):** Use `headline-sm` for section headers. These provide the structural "architecture" of the page.
*   **The Functional Tier (Inter):** All `body` and `label` styles use Inter. This ensures maximum readability for complex productivity tasks. Use `label-md` in All Caps with +0.05em letter-spacing for category tags to enhance the editorial feel.

## 4. Elevation & Depth: The Layering Principle
Depth is achieved through **Tonal Layering** rather than traditional drop shadows.

*   **Stacking:** Instead of a shadow, place a `surface_container_lowest` (#020f1e) component inside a `surface_container_high` (#1e2b3b) area to create a "recessed" or "inset" feel.
*   **Ambient Shadows:** For floating elements (like AI tooltips), use a shadow with a blur of 32px or higher and an opacity of 6%. The shadow color must be tinted with `primary` to simulate light refracting through glass.
*   **The "Ghost Border":** If a boundary is strictly required for accessibility, use the `outline_variant` token at 15% opacity. Never use 100% opaque lines.
*   **Glassmorphism:** Floating panels (e.g., Command Palettes) must use `surface_container_high` at 60% opacity with a `backdrop-filter: blur(20px)`. This integrates the UI into the background, preventing a "pasted-on" look.

## 5. Components

### Buttons
*   **Primary:** A gradient fill (`primary` to `primary_container`). Use `full` roundedness for a modern, high-tech feel.
*   **Secondary:** No fill. Use a "Ghost Border" and `on_surface` text. On hover, apply a subtle `primary` outer glow (4px blur).
*   **Tertiary:** Transparent background with `primary` text. No container.

### Input Fields & Text Areas
*   Avoid the 4-sided box. Use a `surface_container_highest` background with a 2px bottom-weighted accent in `primary` that illuminates only when the field is focused.

### AI Insight Cards
*   **Visual Style:** Forbid divider lines. Use `body-md` for content and `display-sm` for the "Primary Data Point." 
*   **Separation:** Use vertical white space (32px or 48px from the spacing scale) to delineate content blocks.

### The "Pulse" (System Specific)
*   An AI status indicator. A small circle using `secondary` (#95d4b3) with a breathing animation (opacity 1.0 to 0.4). It signifies the AI is actively "thinking" or processing in the background.

## 6. Do's and Don'ts

| Do | Don't |
| :--- | :--- |
| **Do** use `surface_container` shifts to define zones. | **Don't** use 1px solid borders to separate sections. |
| **Do** use Space Grotesk for large, impactful numbers. | **Don't** use Space Grotesk for long-form body copy. |
| **Do** apply `backdrop-blur` to floating navigation elements. | **Don't** use pure black (#000000) for shadows or backgrounds. |
| **Do** use `tertiary` (#ffba27) for high-priority alerts only. | **Don't** use `tertiary` for standard decorative elements. |
| **Do** lean into intentional asymmetry in the layout. | **Don't** force every element into a perfectly centered box. |